
DAY 01 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial1
        |-- PythonNotes
            |-- PythonStudyNotes1.pdf             [ EASY ]
            |-- Python.02.DataTypes.pdf           [ INTERMEDIATE ]
            |-- Python.03.CollectionDataTypes.pdf [ INTERMEDIATE ]

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial1
        |-- PythonCode
        |   |-- Experiement1.py
        |   |-- Hello.py
        |   `-- PythonCollectionsCommented.py

3.  Practice Code Examples

    |-- StudyMaterial1        .
        |-- Module01.PythonIntroduction
        |   |-- average1_ans.py
        |   |-- average2_ans.py
        |   |-- awfulpoetry1_ans.py
        |   |-- awfulpoetry2_ans.py
        |   |-- bigdigits.py
        |   |-- bigdigits_ans.py
        |   |-- echoargs.py
        |   |-- generate_grid.py
        |   |-- hello.py
        |   |-- sum1.py
        |   `-- sum2.py
        |-- Module02.DataTypes
            |-- csv2html.py
            |-- csv2html1_ans.py
            |-- csv2html2_ans.py
            |-- print_unicode.py
            |-- print_unicode_ans.py
            |-- print_unicode_uni.py
            |-- print_unicode_uni_ans.py
            |-- quadratic.py
            |-- quadratic_ans.py
            |-- quadratic_uni.py
            |-- quadratic_uni_ans.p


DAY 02 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial2        .
        |-- PythonNotes
            |-- PythonStudyNotes2.pdf             [ EASY ]
            |-- Python.04.ControlStructuresAndFunctions.pdf [ INTERMEDIATE ]
    
2.  Experiment And Revise Code Examples
    
        StudyMaterial2
        |
        |-- PythonCode
        |   |-- Hello.py
        |   |-- PythonCollections.py
        |   |-- PythonExperiment1.1.py
        |   |-- PythonExperiment1.py
        |   |-- PythonExperiment2.1.py
        |   |-- PythonFunctions.py
        |   `-- PythonFunctionsMore.py


3.  Practice Code Examples

        StudyMaterial2
        |
        |-- PracticePythonCode
        |   |-- Module03.CollectionDataTypes
        |   |   |-- external_sites.py
        |   |   |-- external_sites_ans.py
        |   |   |-- generate_test_names1.py
        |   |   |-- generate_test_names2.py
        |   |   |-- generate_usernames.py
        |   |   |-- generate_usernames_ans.py
        |   |   |-- grepword.py
        |   |   |-- statistics.py
        |   |   |-- uniquewords1.py
        |   |   |-- uniquewords2.py
        |   |   `-- uniquewords_ans.py
        |   `-- Module04.ControlStructuresAndFunctions
        |       |-- TextUtil.py
        |       |-- Util.py
        |       |-- checktags.py
        |       |-- demoFile
        |       |-- demoFile.nb
        |       |-- digit_names.py
        |       |-- listkeeper.py
        |       |-- make_html_skeleton.py
        |       `-- noblanks.py


DAY 03 : ASSIGNMENTS
________________________________________________________________

