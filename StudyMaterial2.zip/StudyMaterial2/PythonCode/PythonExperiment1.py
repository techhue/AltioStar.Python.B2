
>>> math.cos(angle)
6.123233995736766e-17
>>> 
>>> math.sin(angle)
1.0
>>> 
>>> 
>>> dir(math)
['__doc__', '__loader__', '__name__', '__package__', '__spec__', 'acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'comb', 'copysign', 'cos', 'cosh', 'degrees', 'dist', 'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd', 'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'isqrt', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2', 'modf', 'nan', 'perm', 'pi', 'pow', 'prod', 'radians', 'remainder', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc']
>>> 
>>> math.degrees(angle)
90.0
>>> 
>>> math.radians(90.0)
1.5707963267948966
>>> 
>>> 
>>> math.sqrt(25)
5.0
>>> math.floor(9.89)
9
>>> math.ceil(9.89)
10
>>> math.pi
3.141592653589793
>>> 
>>> 
>>> math.isinf(90)
False
>>> 
>>> math.isinf(1/0)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ZeroDivisionError: division by zero
>>> 
>>> math.isNan(1/0)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: module 'math' has no attribute 'isNan'
>>> 
>>> math.isnan(1/0)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ZeroDivisionError: division by zero
>>> 
>>> 
>>> z = 10 + 20j
>>> z
(10+20j)
>>> 
>>> type(z)
<class 'complex'>
>>> 
>>> z1 = 1 + 2j
>>> z2 = 10 + 20j
>>> 
>>> z3 = z1 + z2
>>> 
>>> z3
(11+22j)
>>> 
>>> z2.real
10.0
>>> z2.imag
20.0
>>> z1.real
1.0
>>> z1.imag
2.0
>>> 
>>> z3.conjugate()
(11-22j)
>>> 
>>> 
>>> ff = 98.897786756744676666767896644311
>>> 
>>> ff
98.89778675674468
>>> 
>>> ff = 98.12345678901234567890
>>> 
>>> ff
98.12345678901235
>>> 
>>> 
>>> 
>>> 
>>> import decimal
>>> 
>>> dd = decimal.Decimal("98.12345678901234567890")
>>> 
>>> dd
Decimal('98.12345678901234567890')
>>> type(decimal)
<class 'module'>
>>> 
>>> 
>>> type(dd)
<class 'decimal.Decimal'>
>>> 
>>> ddd = decima.Decimal("98.897786756744676666767896644311")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'decima' is not defined
>>> 
>>> ddd = decimal.Decimal("98.897786756744676666767896644311")
>>> 
>>> ddd
Decimal('98.897786756744676666767896644311')
>>> 
>>> ff + dd
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unsupported operand type(s) for +: 'float' and 'decimal.Decimal'
>>> 
>>> dd + ddd
Decimal('197.0212435457570223456678966')
>>> 
>>> ff + fff
98.12434678901235
>>> 
>>> 
>>> 
>>> greeting = "Hello World!"
>>> 
>>> greetingAgain = 'Hello World!'
>>> 
>>> geeting
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'geeting' is not defined
>>> greeting
'Hello World!'
>>> greetingAgain
'Hello World!'
>>> type(greeting)
<class 'str'>
>>> type(greetingAgain)
<class 'str'>
>>> 
>>> 
>>> greeting == greetingAgain
True
>>> 
>>> something = "Ding Dong"
>>> 
>>> greeting == something
False
>>> greeting != something
True
>>> 
>>> greeting != greetingAgain
False
>>> 
>>> greeting
'Hello World!'
>>> greeting[0]
'H'
>>> greeting[1]
'e'
>>> l = len(greeting)
>>> l
12
>>> greeting[ l -1 ]
'!'
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> length = len(greeting)
>>> legth
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'legth' is not defined
>>> 
>>> length
12
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[0]
'H'
>>> greeting[ length ]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> greeting[ length - 1 ]
'!'
>>> greeting
'Hello World!'
>>> greeting[0: length - 1]
'Hello World'
>>> 
>>> greeting[0: length - 3]
'Hello Wor'
>>> 
>>> greeting[0: length - 5]
'Hello W'
>>> 
>>> greeting[3: length - 1]
'lo World'
>>> 
>>> greeting[3: length - 3]
'lo Wor'
>>> 
>>> greeting[-1]
'!'
>>> greeting[-2]
'd'
>>> greeting[-3]
'l'
>>> greeting[-4]
'r'
>>> greeting[-length, -1]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: string indices must be integers
>>> 
>>> greeting[-length :  -1]
'Hello World'
>>> 
>>> greeting[-1 :  -length ]
''
>>> greeting[-1]
'!'
>>> greeting[:-1]
'Hello World'
>>> 
>>> greeting[0]
'H'
>>> 
>>> greeting[-12]
'H'
>>> 
>>> greeting[3:7]
'lo W'
>>> 
>>> greeting[0 : length]
'Hello World!'
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[::]
'Hello World!'
>>> 
>>> greeting[0::]
'Hello World!'
>>> greeting[0:]
'Hello World!'
>>> 
>>> greeting[0 : length : 1]
'Hello World!'
>>> 
>>> greeting[0 : length : 2]
'HloWrd'
>>> greeting[0 : length : 3]
'HlWl'
>>> 
>>> 
>>> greeting[::]
'Hello World!'
>>> 
>>> greeting[::2]
'HloWrd'
>>> greeting[::3]
'HlWl'
>>> 
>>> greeting[3::3]
'lWl'
>>> 
>>> greeting[::-1]
'!dlroW olleH'
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting.lower()
'hello world!'
>>> greeting.upper()
'HELLO WORLD!'
>>> 
>>> greeting.title()
'Hello World!'
>>> 
>>> greeting.isupper()
False
>>> 
>>> greeting.upper().isupper()
True
>>> 
>>> greeting.split()
['Hello', 'World!']
>>> 
>>> 
>>> something = "       some string... dataa....      "
>>> 
>>> something
'       some string... dataa....      '
>>> 
>>> something.strip)_
  File "<stdin>", line 1
    something.strip)_
                   ^
SyntaxError: unmatched ')'
>>> 
>>> something.strip()
'some string... dataa....'
>>> 
>>> 
>>> something.lstrip()
'some string... dataa....      '
>>> something.rstrip()
'       some string... dataa....'
>>> 
>>> 
>>> 
>>> 
>>> soemthing
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'soemthing' is not defined
>>> 
>>> something
'       some string... dataa....      '
>>> 
>>> something.find("data")
22
>>> 
>>> greeting
'Hello World!'
>>> greeting.find("ll")
2
>>> 
>>> "Sky is {0} and Ocean is {1}".format(
... "Blue", "Green")
'Sky is Blue and Ocean is Green'
>>> 
>>> 
>>> "Sky is {0} and Ocean is {1}".format("Blue", "Green")
'Sky is Blue and Ocean is Green'
>>> 
>>> 
>>> "Sky is {0} and Ocean is {1}".format("Blue", 9000)
'Sky is Blue and Ocean is 9000'
>>> 
>>> newString = "Sky is {0} and Ocean is {1}".format("Blue", 9000)
>>> 
>>> newString
'Sky is Blue and Ocean is 9000'
>>> 
>>> 
>>> 
>>> coodinates = {10, 20)
  File "<stdin>", line 1
    coodinates = {10, 20)
                        ^
SyntaxError: closing parenthesis ')' does not match opening parenthesis '{'
>>> 
>>> point = (10, 20)
>>> 
>>> type(point)
<class 'tuple'>
>>> 
>>> point[0]
10
>>> point[1]
20
>>> 
>>> something = ( "Ding", "Dong", 100, 199, (1000, 2000), 90.89)
>>> 
>>> something
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> point
(10, 20)
>>> len(something)
6
>>> 
>>> len(point)
2
>>> 
>>> something[0]
'Ding'
>>> something[1]
'Dong'
>>> something[2]
100
>>> something[3]
199
>>> something[4]
(1000, 2000)
>>> something[5]
90.89
>>> 
>>> something[0]
'Ding'
>>> something[0][0]
'D'
>>> something[0][1]
'i'
>>> something[0][2]
'n'
>>> something[4]
(1000, 2000)
>>> something[4][0]
1000
>>> something[4][2]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: tuple index out of range
>>> something[4][1]
2000
>>> 
>>> 
>>> point
(10, 20)
>>> 
>>> point[0]
10
>>> point[0] = 100
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> greeting
'Hello World!'
>>> greeting[0]
'H'
>>> greeting[0] = 'K'
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'str' object does not support item assignment
>>> 
>>> 
>>> 
>>> something
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greetingNew = greeting + " Asywarya!"
>>> 
>>> greetingNew
'Hello World! Asywarya!'
>>> 
>>> tuple1 = (10, 20, 30)
>>> tuple2 = (100, 200)
>>> 
>>> tuple3  = tuple1 + tuple2
>>> 
>>> tuple3
(10, 20, 30, 100, 200)
>>> 
>>> tuple4 = ( tuple1, tuple2, greeting, something)
>>> 
>>> tuple4
((10, 20, 30), (100, 200), 'Hello World!', ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89))
>>> 
>>> tuple4[0]
(10, 20, 30)
>>> tuple4[1]
(100, 200)
>>> tuple4[2]
'Hello World!'
>>> tuple4[2][2]
'l'
>>> 
>>> tuple4[3]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> tuple4[3][0]
'Ding'
>>> 
>>> tuple4[3][0][1]
'i'
>>> 

>>> for item in tuple4:
...     print(item)
... 
(10, 20, 30)
(100, 200)
Hello World!
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> numbers[0:6]
(1, 2, 3, 4, 5, 6)
>>> 
>>> numbers[3:6]
(4, 5, 6)
>>> numbers[-1]
90
>>> numbers[-2]
8
>>> numbers[-3]
7
>>> numbers[0:6:2]
(1, 3, 5)
>>> 
>>> 
>>> point
(10, 20)
>>> 
>>> a, b = point

>>> point
(10, 20)
>>> 
>>> a, b = point
>>> 
>>> a
10
>>> b
20
>>> point5 = (10, 20, 30, 40, 99)
>>> 
>>> point5
(10, 20, 30, 40, 99)
>>> 
>>> a, b, c, d, e = point5
>>> a
10
>>> b
20
>>> c
30
>>> d
40
>>> e
99
>>> f
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'f' is not defined
>>> 
>>> a, *b = point5
>>> 
>>> a
10
>>> b
[20, 30, 40, 99]
>>> a, *b, c = point5
>>> 
>>> a
10
>>> b
[20, 30, 40]
>>> c
99

>>> 
>>> 
>>> aa = 1000
>>> bb = 2000
>>> 
>>> bb, aa = (aa, bb)
>>> 
>>> bb
1000
>>> aa
2000
>>> 
>>> points = ( (10, 20),  (100, 200), (99, 88), (0, 0), (10, 10))


>>> points = ( (10, 20),  (100, 200), (99, 88), (0, 0), (10, 10))
>>> 
>>> for point in points:
...     print(point)
... 
(10, 20)
(100, 200)
(99, 88)
(0, 0)
(10, 10)
>>> 
>>> for xCoordinate, yCoordinate in points:
...     print(xCoordinate)
...     print(yCoordinate)
... 
10
20
100
200
99
88
0
0
10
10
>>> for xCoordinate, yCoordinate in points:
...     print( " X Coordinate = {0} and Y Cooridnate = {1}".format(xCoordinate, yCoordinate) )
... 
 X Coordinate = 10 and Y Cooridnate = 20
 X Coordinate = 100 and Y Cooridnate = 200
 X Coordinate = 99 and Y Cooridnate = 88
 X Coordinate = 0 and Y Cooridnate = 0
 X Coordinate = 10 and Y Cooridnate = 10


__________________________________________________________-

>>> 
>>> numbersAgain = [10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> type(numbers)
<class 'tuple'>
>>> 
>>> numbersAgain
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> type(numbersAgain)
<class 'list'>
>>> 
>>> for number in numbersAgain:
...     print(number)
... 
10
20
30
40
50
60
70
80
99
>>> numbersAgain[0]
10
>>> numbersAgain[1]
20
>>> numbersAgain[2: 8]
[30, 40, 50, 60, 70, 80]
>>> 
>>> numbersAgain[2: 8: 2]
[30, 50, 70]
>>> 
>>> nestedList = [ numbers, numbersAgain, something, greeting ]
>>> 
>>> nestedList
[(1, 2, 3, 4, 5, 6, 7, 8, 90), [10, 20, 30, 40, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']
>>> 
>>> 
>>> nestedList[0]
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> nestedList[1]
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> nestedList[2]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> nestedList[3]
'Hello World!'
>>> 
>>> nestedList[-1]
'Hello World!'
>>> 
>>> numbersAgain[-1]
99
>>> numbersAgain[-2]
80
>>> 
>>> 
>>> numbersAgain
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbersAgain[0] = 1000
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> numbers[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment


__________________________________________________________________________


>>> numbersAgain = [10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> type(numbers)
<class 'tuple'>
>>> 
>>> numbersAgain
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> type(numbersAgain)
<class 'list'>
>>> 
>>> for number in numbersAgain:
...     print(number)
... 
10
20
30
40
50
60
70
80
99
>>> numbersAgain[0]
10
>>> numbersAgain[1]
20
>>> numbersAgain[2: 8]
[30, 40, 50, 60, 70, 80]
>>> 
>>> numbersAgain[2: 8: 2]
[30, 50, 70]
>>> 
>>> nestedList = [ numbers, numbersAgain, something, greeting ]
>>> 
>>> nestedList
[(1, 2, 3, 4, 5, 6, 7, 8, 90), [10, 20, 30, 40, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']
>>> 
>>> 
>>> nestedList[0]
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> nestedList[1]
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> nestedList[2]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> nestedList[3]
'Hello World!'
>>> 
>>> nestedList[-1]
'Hello World!'
>>> 
>>> numbersAgain[-1]
99
>>> numbersAgain[-2]
80
>>> 
>>> 
>>> numbersAgain
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbersAgain[0] = 1000
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> numbers[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> nestedList
[(1, 2, 3, 4, 5, 6, 7, 8, 90), [1000, 20, 30, 40, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']
>>> 
>>> nestedList[2]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> nestedList[2][1]
'Dong'
>>> 
>>> nestedList[2][1][1]
'o'
>>> 
>>> nestedList[4]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: list index out of range
>>> 
>>> nestedList[3]
'Hello World!'
>>> 
>>> nestedList[3][1]
'e'
>>> 
>>> nestedList[2][1]
'Dong'
>>> 
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> 
>>> first, *rest = numbersAgain
>>> 
>>> first
1000
>>> rest
[20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> first, *rest, secondLast, last  = numbersAgain
>>> 
>>> first 
1000
>>> last
99
>>> secondLast
80
>>> rest
[20, 30, 40, 50, 60, 70]
>>> 
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> dir(numbers)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
>>> numbers.count(8)
1
>>> 
>>> numbers.index(8)
7
>>> 
>>> 
>>> 
>>> dir(tuple)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
>>> 
>>> 
>>> dir(list)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> 
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numberAgain.append(999)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'numberAgain' is not defined
>>> 
>>> numbersAgain.append(999)
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 50, 60, 70, 80, 99, 999]
>>> 
>>> numbersAgain.pop()
999
>>> numbersAgain.remove(4)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: list.remove(x): x not in list
>>> 
>>> numbersAgain.remove(50)
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 60, 70, 80, 99]
>>> insert(555, 30)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'insert' is not defined
>>> 
>>> numbersAgain.insert(555, 30)
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 60, 70, 80, 99, 30]
>>> 
>>> numbersAgain.insert(555, 3)
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 60, 70, 80, 99, 30, 3]
>>> 
>>> help(list.insert)

>>> 
>>> numbersAgain.insert(3, 888)
>>> 
>>> numbersAgain
[1000, 20, 30, 888, 40, 60, 70, 80, 99, 30, 3]
>>> 
>>> numbersAgain.reverse()
>>> 
>>> numberAgain()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'numberAgain' is not defined
>>> 
>>> numbersAgain()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'list' object is not callable
>>> 
>>> numbersAgain
[3, 30, 99, 80, 70, 60, 40, 888, 30, 20, 1000]
>>> 
>>> numbersAgain.sort()
>>> 
>>> numbersAgain
[3, 20, 30, 30, 40, 60, 70, 80, 99, 888, 1000]
>>> 
>>> dir(list)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> 
>>> 
>>> 
>>> 
>>> numbersAgain = numbersAgain + [9000, 8000]
>>> 
>>> numbersAgain
[3, 20, 30, 30, 40, 60, 70, 80, 99, 888, 1000, 9000, 8000]
>>> 
>>> 
>>> 
>>> 
>>> s = { 10, 20, "Ding", "Dong", 30, 20,  10}
>>> 
>>> s
{'Dong', 'Ding', 10, 20, 30}
>>> 
>>> type(s)
<class 'set'>
>>> 
>>> 
>>> 
>>> setA = { 10, 20, "Ding", "Dong", 30, 20,  10}
>>> 
>>> setA
{'Dong', 'Ding', 10, 20, 30}
>>> 
>>> setB = { 100, 200, "Ping}, 10, 20, "Ding" }
  File "<stdin>", line 1
    setB = { 100, 200, "Ping}, 10, 20, "Ding" }
                                        ^
SyntaxError: invalid syntax
>>> 
>>> setB = { 100, 200, "Ping", 10, 20, "Ding" }
>>> 
>>> setB
{100, 200, 'Ding', 10, 20, 'Ping'}
>>> setA
{'Dong', 'Ding', 10, 20, 30}
>>> 
>>> setA.union(setB)
{'Dong', 100, 200, 'Ding', 10, 20, 'Ping', 30}
>>> 
>>> setA.intersection(setB)
{'Ding', 10, 20}
>>> 
>>> dir(set)
['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__iand__', '__init__', '__init_subclass__', '__ior__', '__isub__', '__iter__', '__ixor__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']
>>> 
>>> help(list.union)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: type object 'list' has no attribute 'union'
>>> 
>>> help(s.union)

>>> 
>>> help(union)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'union' is not defined
>>> 
>>> 
>>> setA.difference(setB)
{'Dong', 30}
>>> 
>>> setA
{'Dong', 'Ding', 10, 20, 30}
>>> setB
{100, 200, 'Ding', 10, 20, 'Ping'}
>>> 
>>> 
>>> for item in setA:
...     print(item)
... 
Dong
Ding
10
20
30
>>> 
>>> for item in setB:
...     print(item)
... 
100
200
Ding
10
20
Ping
>>> 
>>> 

____________________________________________________________________



>>> frozenSetA = frozenset()
>>> 
>>> 
>>> frozenSetA = frozenset( setA )
>>> 
>>> frozenSetA
frozenset({'Dong', 20, 1000, 'Ding', 10, 30})
>>> 
>>> dir(frozenSetA)
['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'copy', 'difference', 'intersection', 'isdisjoint', 'issubset', 'issuperset', 'symmetric_difference', 'union']
>>> 
>>> 
>>> 
>>> setA
{'Dong', 1000, 'Ding', 10, 20, 30}
>>> 
>>> setC = {'Dong', 1000, 'Ding', 10, 20, 30}
>>> setC = {'Dong', 1000, 'Ding', 10, 20, 30, "Ting", "Tong", 1000 }
>>> 
>>> setC
{'Dong', 'Ting', 1000, 'Ding', 10, 'Tong', 20, 30}
>>> 
>>> setA.issubset(setC)
True
>>> 
>>> setA.issubset(setB)
False
>>> 
>>> setB
{100, 200, 'Ding', 10, 20, 'Ping'}
>>> 
>>> setA
{'Dong', 1000, 'Ding', 10, 20, 30}
>>> 
>>> 
>>> 
>>> ageNameDictionary = { 20: "Lewis Carol", 25: "Alice", 15: "Ram Singh", 40: "Gabbar Singh", 60: "Thakkur" }
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}
>>> 
>>> ageNameDictionary[20]
'Lewis Carol'
>>> 
>>> ageNameDictionary[40]
'Gabbar Singh'
>>> 
>>> ageNameDictionary[44]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 44
>>> 
>>> 
>>> ageNameDictionary.keys()
dict_keys([20, 25, 15, 40, 60])
>>> 
>>> ageNameDictionary.values()
dict_values(['Lewis Carol', 'Alice', 'Ram Singh', 'Gabbar Singh', 'Thakkur'])
>>> 
>>> 
>>> ageNameDictionary.items()
dict_items([(20, 'Lewis Carol'), (25, 'Alice'), (15, 'Ram Singh'), (40, 'Gabbar Singh'), (60, 'Thakkur')])
>>> 
>>> 
>>> 
>>> for key in ageNameDictionary.keys():
...     print(key)
... 
20
25
15
40
60
>>> 
>>> for values in ageNameDictionary.values():
... 
KeyboardInterrupt
>>> 
>>> for values in ageNameDictionary.values():
...     print(values)
... 
Lewis Carol
Alice
Ram Singh
Gabbar Singh
Thakkur
>>> 
>>> 
>>> for item in ageNameDictionary.items():
...     print(item)
... 
(20, 'Lewis Carol')
(25, 'Alice')
(15, 'Ram Singh')
(40, 'Gabbar Singh')
(60, 'Thakkur')
>>> 
>>> 
>>> for key, value in ageNameDictionary.items():
...     print(" For Key = {0} and Value = {1}".format(key, value))
... 
 For Key = 20 and Value = Lewis Carol
 For Key = 25 and Value = Alice
 For Key = 15 and Value = Ram Singh
 For Key = 40 and Value = Gabbar Singh
 For Key = 60 and Value = Thakkur
>>> 
>>> 
>>> 


>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}
>>> 
>>> type(ageNameDictionary)
<class 'dict'>
>>> 
>>> 
>>> ageNameDictionary[44]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 44
>>> 
>>> ageNameDictionary[25] = 'Alice Thomson'
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice Thomson', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}
>>> 
>>> ageNameDictionary[44] = 'Sholay'
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice Thomson', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur', 44: 'Sholay'}
>>> 
>>> 
>>> dir(dict)
['__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values']
>>> 
>>> ageNameDictionary[25]
'Alice Thomson'
>>> 
>>> ageNameDictionary.get(25)
'Alice Thomson'
>>> 
>>> ageNameDictionary.get(50)
>>> 
>>> ageNameDictionary.get(50, "Unknown Value")
'Unknown Value'
>>> 
>>> ageNameDictionary.get(25, "Unknown Value")
'Alice Thomson'
>>> 
>>> ageNameDictionary.update(15, "Sambha")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: update expected at most 1 argument, got 2
>>> 
>>> ageNameDictionary.update(15)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'int' object is not iterable
>>> 
>>> help(ageNameDictionary.update)

>>> 
>>> 
>>> 
>>> len(ageNameDictionary)
6
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice Thomson', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur', 44: 'Sholay'}
>>> 
>>> 
>>> 
>>> 
>>> a = 90
>>> 
>>> a = 0
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> a = int()
>>> 
>>> type(a)
<class 'int'>
>>> a
0
>>> 
>>> f = float()
>>> 
>>> f
0.0
>>> 
>>> s = str()
>>> 
>>> type(s)
<class 'str'>
>>> s
''
>>> 
>>> t = tuple()
>>> type(t)
<class 'tuple'>
>>> 
>>> t
()
>>> 
>>> l = list()
>>> 
>>> type(l)
<class 'list'>
>>> l
[]
>>> 
>>> ss = set()
>>> 
>>> ss
set()
>>> type(ss)
<class 'set'>
>>> 
>>> dd = dict()
>>> 
>>> dd
{}
>>> 
>>> type(dd)
<class 'dict'>
>>> 
>>> 
>>> 
>>> aa = int(10)
>>> type(aa)
<class 'int'>
>>> 
>>> aa
10
>>> 
>>> ff = float(90.99)
>>> 
>>> ff
90.99
>>> type(float)
<class 'type'>
>>> 
>>> 
>>> ss = str("Ding Dong")
>>> 
>>> ss
'Ding Dong'
>>> 
>>> 
>>> tt = tuple( (10, 20, 30) )
>>> 
>>> tt
(10, 20, 30)
>>> 
>>> ll = list( (10, 20, 20 ) )
>>> 
>>> ll
[10, 20, 20]
>>> 
>>> lll = list( [ 10, 20, 20 ] )
>>> 
>>> lll
[10, 20, 20]
>>> 
>>> ttt = tuple( "Hello" )
>>> 
>>> ttt
('H', 'e', 'l', 'l', 'o')
>>> 
>>> listHellow = list( "Hello World"  )
>>> 
>>> listHellow
['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']
>>> 
>>> 
>>> for character in "Hello":
...     print(character)
... 
H
e
l
l
o
>>> 











