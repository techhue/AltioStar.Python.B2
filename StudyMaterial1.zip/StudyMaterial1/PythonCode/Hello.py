#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

# Line Starting With # Is Comment In Python

# Defining Function 
#    Which Takes No Arguments And Returns Nothing

def helloWorld():
    print("Hello World")
    print("My Environment Is Ready!!!...")

print("\nFunction : helloWorld()")
helloWorld()

#______________________________________________________
# Run Following Code In IDLE Shell To Check Output
# dir()
# dir(__builtins__) 

# __builtins__ gives Python Language Defined Keywords 
#  and Predefined Identifiers Having Special Meaning In
#  Python Language

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

def playWithIntDataType():
    a = 20 # Assigning 20 Value To a 
    b = 30 # Assigning 30 Value To b 
    c = a + b # Calculating Sum And Storing Result In c

    print(a)
    print(b)
    print(c)
    print(type(a)) # int Type Data
    print(type(b)) # int Type Data
    print(type(c)) # int Type Data

print("\nFunction : playWithIntDataType()")
playWithIntDataType()

#______________________________________________________

def playWIthIntOperators():
    a = 44
    b = 20
    c = a + b
    print(c)
    c = a - b
    print(c)
    c = a * b
    print(c)
    c = a / b # Floating Point Result 2.2
    print(c)
    c = a // b # int Result 2 i.e. Integer Arithmatic
    print(c)
    c = a % b
    print(c)
    c = -a
    print(c)
    c = 5**3 # 5 Raised To Power 3
    print(c)

print("\nFunction : playWIthIntOperators()")
playWIthIntOperators()

#______________________________________________________

def playWithNumbericFunctions():
    x = -90
    a = 20
    b = 9

    result = abs(x)
    print(result)
    result = divmod(a, b) # Gives Qutotien and Remainder
    print(result)
    result = pow(2, 3)
    print(result)
    result = pow(10, 3, 8) # (10**3) % 8
    print(result)
    result = round(90.89787)
    print(result)
    result = round(90.89787, 3)
    print(result)
    result = bin(8)
    print(result)
    result = hex(16)
    print(result)
    result = oct(8)
    print(result)
    result = int("456") # Convering String To Int Type Data
    print(result)
    result = int("456", 10) # Convering String To Int Type Data With Base 10
    print(result)

print("\nFunction : playWithNumbericFunctions")

playWithNumbericFunctions()

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

def playWithIntegerDataRepresentation():
    a = 10      #  Decimal Integer In Base 10
    print(a)
    a = 0b1010  #  Binary Integer In Base 2
    print(a)
    a=0o12      #  Octal Integer In Base 8
    print(a)
    a=0x40      #  Hexadecimal Integer In Base 16
    print(a)    #  64 In Base 10

print("\nFunction : playWithIntegerDataRepresentation")
playWithIntegerDataRepresentation()

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

def playWithBitwiseOperators():
    a = 0b1010
    b = 0b1110
    result = a | b
    print(result)
    print(bin(result))
    result = a & b
    print(result)
    result = a << 2
    print(result)
    result = a >> 2
    print(result)
    result = ~a
    print(result)

print("\nFunction : playWithBitwiseOperators")
playWithBitwiseOperators()

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

#print("\nFunction : ")

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

#print("\nFunction : ")

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

#print("\nFunction : ")

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

#print("\nFunction : ")

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!

#print("\nFunction : ")

#______________________________________________________
# MOMENT YOU ARE DONE, PLEASE RAISE YOUR HAND!!!
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
#print("\nFunction : ")
