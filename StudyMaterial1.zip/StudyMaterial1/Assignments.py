
DAY 1 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial1
        |-- PythonNotes
            |-- PythonStudyNotes1.pdf             [ EASY ]
            |-- Python.02.DataTypes.pdf           [ INTERMEDIATE ]
            |-- Python.03.CollectionDataTypes.pdf [ INTERMEDIATE ]

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial1
        |-- PythonCode
        |   |-- Experiement1.py
        |   |-- Hello.py
        |   `-- PythonCollectionsCommented.py

3.  Practice Code Examples

    |-- StudyMaterial1        .
        |-- Module01.PythonIntroduction
        |   |-- average1_ans.py
        |   |-- average2_ans.py
        |   |-- awfulpoetry1_ans.py
        |   |-- awfulpoetry2_ans.py
        |   |-- bigdigits.py
        |   |-- bigdigits_ans.py
        |   |-- echoargs.py
        |   |-- generate_grid.py
        |   |-- hello.py
        |   |-- sum1.py
        |   `-- sum2.py
        |-- Module02.DataTypes
            |-- csv2html.py
            |-- csv2html1_ans.py
            |-- csv2html2_ans.py
            |-- print_unicode.py
            |-- print_unicode_ans.py
            |-- print_unicode_uni.py
            |-- print_unicode_uni_ans.py
            |-- quadratic.py
            |-- quadratic_ans.py
            |-- quadratic_uni.py
            |-- quadratic_uni_ans.p


DAY 2 : ASSIGNMENTS
________________________________________________________________


DAY 2 : ASSIGNMENTS
________________________________________________________________


