

def sum(a, b):
	return a + b

def sub(a, b):
	return a - b

def mul(a, b):
	return a * b 

# Higher Order Functions
# 		Functions Which Takes Functions As Argumentt
# Hence calculator is Higher Order Function

def calculator(a, b, operation):
	return operation(a, b)


result = calculator(30, 20, sum)
print(result) # 50

result = calculator(30, 20, sub)
print(result) # 10

result = calculator(30, 20, mul)
print(result) # 600

#_________________________________________________
#_________________________________________________

# Higher Order Functions
# 		Functions Which Can Return Function
# Hence chooseStep is Higher Order Function

def chooseStep(forward):
	# Local Functions	
	def moveBackward(steps):
		steps = steps - 1
		return steps

	def moveForward(steps):
		steps = steps + 1
		return steps

	if(forward == True):
		return moveForward   # Returning Function
	else:
		return moveBackward  # Returning Function

doMagic = chooseStep(True)
print ( doMagic(10) ) # 11
print ( doMagic(11) ) # 12

doMagic = chooseStep(False)
print ( doMagic(10) ) # 9
print ( doMagic(11) ) # 10


