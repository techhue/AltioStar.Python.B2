# Higher Order Function
#		Function Taking Function Argument And
#		Returning A Function

# Decorator Function
#					Gift Is Passed Here

def simpleDecorator( functionPassed ):
	# Local Function

	def wrapper(): # Gift Wrapper
		print("Before functionPassed Called") # Decoration
		functionPassed() # Gift
		print("After functionPassed Called")  # Decoration

	return wrapper # Returning Wrapped/Decorated Gift

# Gift
def sayHello():
	print("Hello!")


print("sayHello Value Before Assignment")
print(sayHello)

#Decorated Gift	<- Decorating  Gift				
sayHello = simpleDecorator( sayHello )

print("sayHello Value After Assignment")
print(sayHello)

# sayHello Value Before Assignment
# <function sayHello at 0x7f475db2b150>
# sayHello Value After Assignment
# <function wrapper at 0x7f475db2b1d0>

sayHello()
# Before functionPassed Called
# Hello!
# After functionPassed Called

#______________________________________________


something = simpleDecorator( sayHello )
type(something) # <class 'function'>

print(something)
 # <function simpleDecorator.<locals>.wrapper at 0x7f7e923393a0>
something()
# Before functionPassed Called
# Hello!
# After functionPassed Called

type(sayHello) 	# <class 'function'>
print(sayHello) # <function sayHello at 0x7f7e92ecf430>
sayHello() 		# Hello!

sayHello = simpleDecorator( sayHello )
type(sayHello) # <class 'function'>
print(sayHello)
# <function simpleDecorator.<locals>.wrapper at 0x7f7e92339430>

sayHello()
# Before functionPassed Called
# Hello!
# After functionPassed Called

#______________________________________________


# Gift
def birthdayGift():
	print("Birthday Gift!!!")

# Gift
def marriageGift():
	print("Marriage Gift!!!")


def decoratorGift( gift, message ):
	# Local Function
	def wrappedGift(): # Gift Wrapper
		print("Wrapping Gift!") # Decoration
		gift()
		print("Decorating Gift")  # Decoration
		print(message)  		# Decoration
	return wrappedGift 	# Returning Wrapped/Decorated Gift


print("Birthday Gift Before Decoration")
print(birthdayGift)

#Decorated Gift	<- Decorating  Gift				
birthdayGift = decoratorGift ( birthdayGift, "Happy Birthday Gabbar Singh!!!" )

print("Birthday Gift After Decoration")
print( birthdayGift )

birthdayGift()


print("Marriage Gift Before Decoration")
print(marriageGift)

#Decorated Gift	<- Decorating  Gift				
marriageGift = decoratorGift ( marriageGift, "Happy Married Life!!! Gabbar Singh!!!" )

print("Marriage Gift After Decoration")
print( marriageGift )

marriageGift()


#______________________________________________


def decoratorGift( gift ):
	# Local Function
	def wrappedGift(message): # Gift Wrapper
		print("Wrapping Gift!") # Decoration
		gift(message)
		print("Decorating Gift")  # Decoration
		# print(message)  		# Decoration
	return wrappedGift 	# Returning Wrapped/Decorated Gift

# Gift
@decoratorGift
def birthdayGift(message):
	print(message)

# Gift
@decoratorGift
def marriageGift(message):
	print(message)

# Gift
@decoratorGift
def teacherDayGift(message):
	print(message)

print( birthdayGift )
birthdayGift("Happy Birthday Gabbar Singh!!!")

print( marriageGift )
birthdayGift("Happy Married Life Gabbar Singh!!!")

print( teacherDayGift )
birthdayGift("Happy Teachers Day Gabbar Singh!!!")


#______________________________________________

# 09.8 Decorators

def decorate(func):
	print("in decorate function, decorating", func.__name__)
	def wrapper_func(*args):
		print("Executing", func.__name__)
		return func(*args)
	return wrapper_func

def myfunction(parameter):
	print(parameter)

myfunction = decorate(myfunction)
# in decorate function, decorating myfunction
myfunction("hello")
# Executing myfunction
# hello


def decorate(func):
	print("in decorate function, decorating", func.__name__)  #1
	def wrapper_func(*args):
		print("Executing", func.__name__)
		return func(*args)
	return wrapper_func                                       #2

@decorate          # myfunction = decorate(myfunction)        
def myfunction(parameter):
	print(parameter)

# in decorate function, decorating myfunction                      #4
myfunction("hello")
# Executing myfunction
# hello


