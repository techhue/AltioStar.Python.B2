
# LEGB Scope Rule

# Builtin Scope

globalVariable = 1999 # Global Scope

def outerFunction():
	global globalVariable
	
	localVariable = 100
	outerData = 99
	globalVariable = 88
	print( "Inside outerFunction {}".format(localVariable) )


	print( "Inside outerFunction {}".format(globalVariable) )

	def localFunction():
		innerData = 999
		print( "Inside localFunction: {}".format(localVariable) )
		print( "Inside localFunction: {}".format(innerData) )
		print( "Inside localFunction: {}".format(outerData)  )

	localFunction()

print("\nCalling Function: outerFunction")
outerFunction()


def outerFunctionAgain(): # Enclosing Scope
	localVariable = 100
	outerData = 99
	print( "Inside outerFunction {}".format(localVariable) )
	print( "Inside outerFunction {}".format(globalVariable) )

	def localFunction(): # Local Scope
		# nonlocal outerData

		innerData = 999
		outerData = 900

		print( "Inside localFunction: {}".format(localVariable) )
		print( "Inside localFunction: {}".format(innerData) )
		print( "Inside localFunction: {}".format(outerData)  )

	localFunction()

print("\nCalling Function: outerFunctionAgain")
outerFunctionAgain()

# Calling Function: outerFunctionAgain
# Inside outerFunction 100
# Inside outerFunction 1999
# Inside localFunction: 100
# Inside localFunction: 999
# Inside localFunction: 900
