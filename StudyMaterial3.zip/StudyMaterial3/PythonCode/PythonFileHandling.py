
def countWordsAndCharacters():
	# First Create wordsList.txt File 
	#	In Same Location As This Python File  
	# 	Add Some Text In wordsList.txt File

	# Opening File In Read Mode
	# Read Mode Is Default
	infile = open("wordsList.txt") 
	
	# Reading File
	fileData = infile.read()
	lines = fileData.split("\n")

	wordsCount = 0
	characterCount = 0

	for line in lines:
	    words = line.split() 
	    wordsCount = wordsCount + len(words)
	    characterCount = characterCount + len(line)

	print(" Words Count = {0}".format( wordsCount ))
	print(" Character Count = {0}".format( characterCount ))


if __name__ == '__main__':
    
    print("\nFunction: countWordsAndCharacters() ")
    countWordsAndCharacters()

