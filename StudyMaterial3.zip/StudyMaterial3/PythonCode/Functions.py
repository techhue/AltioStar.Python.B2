

def helloWorld():
	print("Hello World!")

def dummyFunction():
	pass  # Means Function With Empty Body Used For Future Implementation

def sum(a, b):
	return a + b

def sub(a, b):
	return a - b

# Arguments with Default Values
def mul(a=1, b=1):
	return a * b

# Function With Variable Numbers Of Arguments
def summation( *values ):
	result = 0
	for value in values:
		result = result + value

	return result

def mutliply( values ):
	result = 1
	for value in values:
		result = result * value

	return result

# Function With Variable Numbers Of Arguments
def multipleNamedFunction(**keyValues):
	print(" Argument = {0} and Type = {1}".format(keyValues, type(keyValues) ))
	
	for item in keyValues.items():
		print(item)


# Variable Numbers Of Arguments
def doSomething( first, second, *values , **keyValues):
	print(" Argument = {0} and Type = {1}".format(first, type(first) ))
	print(" Argument = {0} and Type = {1}".format(second, type(second) ))
	print(" Argument = {0} and Type = {1}".format(values, type(values) ))
	print(" Argument = {0} and Type = {1}".format(keyValues, type(keyValues) ))


helloWorld()
dummyFunction()

print( sum(10, 20))
print( sum( "Ding", "Dong") )
print( sum( (10, 20), (100, 200) ) )
print( sum(  (10, 20, 30), ("Ding", "Dong") ) )
print( sum(  [10, 20, 30], ["Ding", "Dong"] ) )

print(sub(20, 10))

# Named Arguments
print( mul(a = 10, b = 20)) # Passing Arguments With Argument Name
print( mul(a = 10) )
print( mul() )


print(summation())
print(summation(10))
print(summation(10, 20))
print(summation(10, 20, 30))
print(summation(10, 40, 50, 70, 90, 10))

numbers = [10, 20, 30, 40, 50, 60]
print( mutliply(numbers) )

print('\nFunction : multipleNamedFunction(ding = "Ding", dong = "Dong", ting = 6666)')
multipleNamedFunction(ding = "Ding", dong = "Dong", ting = 6666)

print("\nFunction : doSomething(10, 20)")
doSomething(10, 20)

print("\nFunction : doSomething(10, 20, third = 99)")
doSomething(10, 20, third = 99)
#doSomething(10, 20, third = 99, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)

print('\nFunction : doSomething(10, 20, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)')
doSomething(10, 20, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)


