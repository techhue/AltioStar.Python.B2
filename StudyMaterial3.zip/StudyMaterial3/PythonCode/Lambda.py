
def sum(a, b):
	return a + b

def sub(a, b):
	return a - b

def mul(a, b):
	return a * b 

# Higher Order Functions
# 		Functions Which Takes Functions As Argumentt
# Hence calculator is Higher Order Function
def calculator(a, b, operation):
	return operation(a, b)

result = calculator(30, 20, sum)
print(result) # 50

result = calculator(30, 20, sub)
print(result) # 10

result = calculator(30, 20, mul)
print(result) # 600

#____________________________________________________________

# Lambda Expressions Also Called Anonymous Functions
#____________________________________________________________


sumLambda = lambda x, y: x + y
subLambda = lambda x, y: x - y
mulLambda = lambda x, y: x * y


# Higher Order Functions
# 		Functions Which Takes Functions As Argumentt
# Hence calculator is Higher Order Function

def calculator(a, b, operation):
	return operation(a, b)


result = calculator(30, 20, sumLambda)
print(result) # 50

result = calculator(30, 20, subLambda)
print(result) # 10

result = calculator(30, 20, mulLambda)
print(result) # 600

#____________________________________________________________
#____________________________________________________________

squareLambda = lambda x : x * x 
cubeLambda = lambda x : x * x * x

print( squareLambda(10) )
print( squareLambda(25) )
print( cubeLambda(10) )
print( cubeLambda(9) )

