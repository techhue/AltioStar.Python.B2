

# Function Doesn't Take Any Argument And Return Value
def helloWorld():
	print("Hello World!")

print("\nFunction : helloWorld")
helloWorld()

# Function Without Empty Body
# Means Function With Empty Body Used For Future Implementation
def dummyFunction():
	pass  

print("\nFunction : dummyFunction")
dummyFunction()

# Function Take Two Argument And Return One Value
def sum(a, b):
	return a + b

print("\nFunction : sum(a, b)")
print( sum(10, 20))
print( sum(99.98, 100.01))
print( sum( "Ding", "Dong") )
print( sum( (10, 20), (100, 200) ) )
print( sum(  (10, 20, 30), ("Ding", "Dong") ) )
print( sum(  [10, 20, 30], ["Ding", "Dong"] ) )

# Positional Arguments
# Function Take Two Argument And Return One Value
def sub(a, b):
	return a - b

print("\nFunction : sub(a, b)")
print( sub(10, 20))
print(sub(200, 10))
print( sub(99.98, 100.01))

# Default Arguments
# Function Take Two Argument And Return One Value
# Arguments with Default Values
def mul(a = 1, b = 1):
	return a * b

print("\nFunction : mul(a, b)")
print( mul(10, 200) )

# Named Arguments
# 	Passing Arguments With Argument Name
print( mul(a = 10, b = 20)) 
print( mul(a = 10) )
print( mul() )

# Function With Variable Numbers Of Positional Arguments
def summation( *values ):
	result = 0
	print( "Arguments {0} With Type {1}"
		.format(values, type(values))) 

	# Iterating On Arguments Tuple
	for value in values: 
		result = result + value

	return result

print("\nFunction : summation( *values )")
print( summation() )
print( summation(10) )
print( summation(10, 20) )
print( summation(10, 20, 30) )
print( summation(10, 40, 50, 70, 90, 10) )

def mutliply( values ):
	result = 1
	for value in values:
		result = result * value

	return result

print("\nFunction : mutliply( values )")
numbers = [1, 2, 3]
print( mutliply(numbers) )

numbers = (1, 2, 3)
print( mutliply(numbers) )

numbers = [10, 20, 30, 40, 50, 60]
print( mutliply(numbers) )

numbers = (10, 20, 30, 40, 50, 60)
print( mutliply(numbers) )


# Function With Variable Numbers Of Key Value Arguments
def functionWithKeyValueArguments(**keyValueArguments):
	print("Arguments = {0} and Type = {1}".format(keyValueArguments, type(keyValueArguments) ))
	
	for item in keyValueArguments.items():
		print(item)

print('\nCalling As : functionWithKeyValueArguments(first = 999)')
functionWithKeyValueArguments(first = 999)

print('\nCalling As : functionWithKeyValueArguments(ding = "Ding")')
functionWithKeyValueArguments(ding = "Ding")

print('\nCalling As : functionWithKeyValueArguments(ding = "Ding", dong = "Dong")')
functionWithKeyValueArguments(ding = "Ding", dong = "Dong")

print('\nCalling As : functionWithKeyValueArguments(first = 10, second = 909.89, third = True)')
functionWithKeyValueArguments(first = 10, second = 909.89, third = True)

print('\nCalling As : functionWithKeyValueArguments(ding = "Ding", dong = "Dong", ting = 6666)')
functionWithKeyValueArguments(ding = "Ding", dong = "Dong", ting = 6666)


# Variable Numbers Of Arguments
def doSomething( first, second, *values , **keyValues):
	print(" Arguments = {0} and Type = {1}".format(first, type(first) ))
	print(" Arguments = {0} and Type = {1}".format(second, type(second) ))
	print(" Arguments = {0} and Type = {1}".format(values, type(values) ))
	print(" Arguments = {0} and Type = {1}".format(keyValues, type(keyValues) ))


print("\nFunction : doSomething(10, 20)")
doSomething(10, 20)

print("\nFunction : doSomething(10, 20, third = 99)")
doSomething(10, 20, third = 99)
#doSomething(10, 20, third = 99, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)

print('\nFunction : doSomething(10, 20, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)')
doSomething(10, 20, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)

