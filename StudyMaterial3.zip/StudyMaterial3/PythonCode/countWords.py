
import string
import sys

wordsCount = {}

# sys.argv Will Gives List Of Command Line Arguments 
print(sys.argv)
# python countWords.py wordsList1.txt
# ['countWords.py', 'wordsList1.txt'] 

# python countWords.py wordsList1.txt wordsList.txt
# ['countWords.py', 'wordsList1.txt', 'wordsList.txt']

for filename in sys.argv[1:]:

 	openedFile = open(filename)
 	lines = openedFile.readlines()

# 	print(lines)
 	for line in lines:
 		words = line.split()

#		print(words)
 		for word in words:
 			word = word.strip()
 			if len(word) >= 2:
				wordsCount[word] = wordsCount.get(word, 0) + 1
#				wordsCount[word] = wordsCount[word] + 1

for word in sorted(wordsCount):
	print(" '{0}' Occurs {1} Times".format(word, wordsCount[word]))

print(wordsCount)

