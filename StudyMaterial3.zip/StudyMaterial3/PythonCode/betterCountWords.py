import string
import sys

files = sys.argv[1:]

def countWords(filenames):
	wordsCount = {}
	for filename in filenames:
	 	openedFile = open(filename)

	 	lines = openedFile.readlines()
	 	
	 	for line in lines:
	 		words = line.split()
	 	
	 		for word in words:
	 			word = word.strip()
	 			if len(word) >= 2:
	 				wordsCount[word] = wordsCount.get(word, 0) + 1

	 	openedFile.close()
	return wordsCount


def countWordsConcise(filenames):
	wordsCount = {}

	for filename in filenames:
	 	for line in open(filename):
	 		for word in line.split():
	 			word = word.strip()
	 			if len(word) >= 2:
	 				wordsCount[word] = wordsCount.get(word, 0) + 1

	return wordsCount

def printWordsCount(words):
	for word in sorted(words):
		print(" '{0}' Occurs {1} Times".format(word, words[word]))

 
def writeWordsToFile(words, filename):
	outfile = open(filename, "w")

	for word in sorted(words):
		data = "'{0}' Occurs {1} Times\n".format(word, words[word])
		outfile.write(data)

	outfile.close()


if __name__ == "__main__":
	
	print("\n Calling Function: countWords")
	wordsFrequency = countWords(files)
	printWordsCount(wordsFrequency)

	print("\n Calling Function: countWordsConcise")
	wordsFrequency = countWordsConcise(files)
	printWordsCount(wordsFrequency)

	writeWordsToFile(wordsFrequency, "wordsFrequency.txt")
