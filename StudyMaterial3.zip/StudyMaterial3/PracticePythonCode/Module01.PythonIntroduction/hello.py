

print("Hello", "World!")
